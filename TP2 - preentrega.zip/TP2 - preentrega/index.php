<!-- 
///  TP 2 - Informática Aplicada I - Micaela Calvo  ///
ABM / Habit tracker  ->  "Habiffy: seguimiento de hábitos" 

* Sobre el desarrollo:
    - Por el momento solo desarrollé el index y agregar.php -> falta editar/borrar + vincular barras de progreso a cada hábito (podría ser quizas con p5js más adelante).
    - Próximamente me gustaría sumar también fechas que se guardarían en el calendario para poder seguir por cuánto tiempo se cumplió un hábito + la posibilidad de escribir y guardar notas.
-->


<?php
require_once("conexion.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Habiffy </title>  
    <link rel="stylesheet" href="css/output.css">   
    <link rel="stylesheet" href="css/styles.css">  
</head>

<body class="bg-verde-claro m-0" id="home">

    <!-- BANNER -->
    <div class="banner bg-verde-oscuro"> 
        <div class="m-[12px]">
            <h1>Habiffy</h1>
            <h2>la constancia se convierte en éxito</h2>
        </div>

        <!-- MENÚ --> 
         <!-- 
         <button id="miPerfil"></button>
         <button id="mode"></button>
         <button id="info"></button>
         -->
    </div>

    <div class="flex justify-center text-center">
        <h3 class="font-semibold">¡Hola de nuevo<?php $NombreUsuario ?>!🫡</h3>  
    </div>

    <div id="contenedor" class= "columns-2 flex flex-wrap justify-center align-center p-10">    
        <div id="izquierda" class="mt-[15px] p-[15px] max-w-[70%]">
            <?php  
                // se crea una consulta SQL que pide todos los registros de la tabla habitos
                $query = "SELECT * FROM habitos"; 
                $result = $mysqli->query($query);

                if ( $result->num_rows<=0 ) {
                echo "<p>No hay registros para mostrar...</p>";
                } else { 
            ?>
                
            <!-- TABLA DE HÁBITOS -->
            <section class="tabla">
                <a href="agregar.php"><button class="btn-primary">+ Nuevo hábito</button></a> 
                <table class="border-separate border-spacing-2 border bg-beige text-center align-center p-[6px] mb-[6px]">
                    <thead>
                        <tr>
                        <th></th>
                        <th class="border p-5">Hábito</th>
                        <th class="border p-5">Frecuencia</th>
                        <th class="border p-5">Día</th>
                        <th class="border p-5">Relevancia</th>
                        <th class="border p-5">Ícono</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php while( $estafila = $result->fetch_array() ) { ?>
                        <tr>

                        <!--  *X/E representan borrar y editar - falta desarrollarlo* -->
                        <th> <span id="borrar">X</span> / <span id="editar">E</span> </th>
                        <td class="border p-5"><?php echo $estafila['habito'];?></td>
                        <td class="border p-5"><?php echo $estafila['frecuencia'];?></td>
                        <td class="border p-5"><?php echo $estafila['dia']?></td>
                        <td class="border p-5"><?php echo $estafila['relevancia']?></td>
                        <td class="border p-5"><?php echo $estafila['icono']?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table> <?php } //end ELSE ?> 
            </section>

            <!-- SECCIÓN DE PROGESO *falta vincular con cada hábito* -->
           <section id="progreso" class="bg-beige mt-[15px] p-[15px] max-w-[70%]">
                <div class="todos">
                    <progress class="progress w-56" value="0" max="100"></progress>
                    <progress class="progress w-56" value="10" max="100"></progress>
                    <progress class="progress w-56" value="40" max="100"></progress>
                    <progress class="progress w-56" value="70" max="100"></progress>
                    <progress class="progress w-56" value="100" max="100"></progress>
                </div>
                <div class="individual">
                   <progress class="progress progress-primary w-56" value="40" max="100"></progress>
                </div>
            </section>

        </div>

        <div id="derecha" class= "flex flex-col max-w-[25%]">   
            <!-- CALENDARIO *por ahora es solo visual, más adelante se conecta con el seguimiento del hábito* -->
            <section class="calendario">        
                <calendar-date class="cally bg-base-100 border border-base-300 shadow-lg rounded-box">
                    <svg aria-label="Previous" class="fill-current size-4" slot="previous" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="M15.75 19.5 8.25 12l7.5-7.5"></path></svg>
                    <svg aria-label="Next" class="fill-current size-4" slot="next" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="currentColor" d="m8.25 4.5 7.5 7.5-7.5 7.5"></path></svg>
                    <calendar-month></calendar-month>
                </calendar-date>
            </section> 

            <!--  
                NOTAS *proximamente*
                <section class="notas" > </section> 
            -->
        </div> 
    </div>

<script type="module" src="https://unpkg.com/cally"></script> <!-- calendario (daisyUI) -->
</body>

</html>
